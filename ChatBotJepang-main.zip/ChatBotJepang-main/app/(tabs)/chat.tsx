import { Text, View } from "react-native";

export default function ChatScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Ini halaman Chat</Text>
    </View>
  );
}
